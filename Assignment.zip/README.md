Road Lane Detection for self driving car
using OpenCV and NumPy
